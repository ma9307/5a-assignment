let insideOfBridge = document.getElementById("inside");

insideOfBridge.addEventListener("click", () => {
  document.getElementById("textbox").innerText =
    "You clicked on the inside of the Jade Belt Bridge in Beijing!";
});


